function varargout = uas(varargin)
%UAS M-file for uas.fig
%      UAS, by itself, creates a new UAS or raises the existing
%      singleton*.
%
%      H = UAS returns the handle to a new UAS or the handle to
%      the existing singleton*.
%
%      UAS('Property','Value',...) creates a new UAS using the
%      given property value pairs. Unrecognized properties are passed via
%      varargin to uas_OpeningFcn.  This calling syntax produces a
%      warning when there is an existing singleton*.
%
%      UAS('CALLBACK') and UAS('CALLBACK',hObject,...) call the
%      local function named CALLBACK in UAS.M with the given input
%      arguments.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help uas

% Last Modified by GUIDE v2.5 20-Jul-2024 09:44:27

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @uas_OpeningFcn, ...
                   'gui_OutputFcn',  @uas_OutputFcn, ...
                   'gui_LayoutFcn',  [], ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
   gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT

% --- Executes just before uas is made visible.
function uas_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   unrecognized PropertyName/PropertyValue pairs from the
%            command line (see VARARGIN)

% Choose default command line output for uas
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% --- Outputs from this function are returned to the command line.
function varargout = uas_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;

% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
loadImage(handles);

% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
detectEdges(handles);

% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
detectContours(handles);

% --- Function to load image
function loadImage(handles)
    [filename, pathname] = uigetfile({'*.jpg;*.png;*.bmp', 'Image Files (*.jpg, *.png, *.bmp)'});
    if isequal(filename, 0)
        return; % Jika pengguna menekan Cancel
    end
    global image;
    image = imread(fullfile(pathname, filename));
    axes(handles.axes1); % Assuming you named the axes as axes1
    imshow(image);
    title('Gambar Asli');
    % Mengaktifkan tombol deteksi
    set(handles.pushbutton2, 'Enable', 'on');
    set(handles.pushbutton3, 'Enable', 'on');

% --- Function to detect edges
function detectEdges(handles)
    global image;
    gray = rgb2gray(image);
    blurred = imgaussfilt(gray, 2);
    edges = edge(blurred, 'Canny');
    axes(handles.axes2); % Assuming you named the axes as axes2
    imshow(edges);
    title('Deteksi Tepi');

% --- Function to detect contours
function detectContours(handles)
    global image;
    gray = rgb2gray(image);
    blurred = imgaussfilt(gray, 2);
    edges = edge(blurred, 'Canny');
    [B, L] = bwboundaries(edges, 'noholes');
    axes(handles.axes3); % Assuming you named the axes as axes3
    imshow(image);
    hold on;
    for k = 1:length(B)
        boundary = B{k};
        plot(boundary(:,2), boundary(:,1), 'g', 'LineWidth', 2);
        if length(boundary) >= 3
            K = convhull(boundary(:,2), boundary(:,1));
            centroid = regionprops(L == k, 'Centroid');
            text(centroid.Centroid(1), centroid.Centroid(2), sprintf('Objek %d', k), 'Color', 'r', 'FontSize', 12);
        end
    end
    hold off;
    title('Deteksi Kontur');
